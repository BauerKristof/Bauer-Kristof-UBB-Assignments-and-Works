osszead([],OSSZ):-OSSZ is 0.
osszead([H|T],OSSZ):-
    osszead(T,X),
    OSSZ is H+X.
