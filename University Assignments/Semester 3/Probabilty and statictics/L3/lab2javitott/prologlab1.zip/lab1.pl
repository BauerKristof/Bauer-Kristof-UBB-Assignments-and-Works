ferfi(adam).
ferfi(ferenc).
ferfi(peter).
ferfi(pali).
ferfi(endre).

add1([],[]).

add1([H1 | T1],[H2|T2]):-
    H2 is H1+1,
    add1(T1,T2).

addif([],[]).
addif([X],[X]).
addif([H11,H12 | T1],[H2 | T2]):-
    H11 < H12,
    H2 is H11+1,
    addif([H12 | T1],T2).

addif([H11,H12 | T1],[H11 | T2]):-
    H11 >= H12,
    addif([H12 | T1], T2).

dupla(k,[],[]).
dupla([H | T1],[H|T2]):-
    dupla(T1,T2).
