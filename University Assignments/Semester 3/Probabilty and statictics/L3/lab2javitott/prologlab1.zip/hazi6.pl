ktorol(Lista,K,MLista):-
    ktorol(Lista,K,0,MLista).

ktorol([],_,_,[]).
ktorol([H1|T1],K,I,[H2|T2]):-
    T is I+1,
    (   T=K -> ktorol(T1,K,0,[H2|T2]);
    H2 is H1,
    ktorol(T1,K,T,T2)).
