compress(L, C) :-
    compress(L, 1, C).

compress([], _, []).
compress([H], Count, [[H,Count]]).

compress([H,H|T], Count, TC) :-
    Count2 is Count +1,
    compress(T,Count2,TC).

compress([H1, H2|T], Count, [[H1,Count]|TC]) :-
    dif(H1, H2),
    Count2 is Count+1,
    compress(H1,Count2,TC).
