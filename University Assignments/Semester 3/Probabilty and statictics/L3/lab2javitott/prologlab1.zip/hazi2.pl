kszoroz(_,[],[]).
kszoroz(K,[H1|T1],Lista):-
    findall(H1, between(1, K, _), L),
    kszoroz(K,T1,Seged),
    append(L,Seged,Lista).


build(X, N, List)  :-
    findall(X, between(1, N, _), List).


inverz1([],[]).
inverz1([H|T],L1):-
     inverz1(T,L2),
     append(L2,[H],L1).

inverz2([],Acc,Acc).
inverz2([H|T],Acc,L):-
    inverz2(T,[H|Acc],L).
