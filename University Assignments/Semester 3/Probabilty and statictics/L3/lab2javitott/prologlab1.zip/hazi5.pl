genList(A,B,Xs):-
    findall(X, between(A, B, X), Xs).
rev(A,L):-
    reverse(A,L),
    display(A).

