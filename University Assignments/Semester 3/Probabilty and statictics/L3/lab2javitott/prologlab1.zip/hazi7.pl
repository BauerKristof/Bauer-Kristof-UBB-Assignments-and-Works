genList(A,B,Xs):-
    findall(X, between(A, B, X), Xs).

is_permutation(Xs, Ys) :-
  msort(Xs, Sorted),
  msort(Ys, Sorted).

perm(L):-
   length(L,N),
   genList(1,N,UList),
   is_permutation(L,UList).
