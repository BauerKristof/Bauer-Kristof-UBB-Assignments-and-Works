genList(A,B,Xs):-
    findall(X, between(A, B, X), Xs).
