% X=[X_i]_{i=1}^n - denotes the sample that has to be generated
%
% distribution_type - a string that identifies the distribution of the random variate X
%
% parameters - an array that stores the parameters of the given distribution
%
% n - denotes the sample size
function X = ExactInversion(distribution_type, parameters, n)
    X = zeros(1,n);

    switch distribution_type
        case 'exp'
            % one parameter: \lambda>0
            lambda = parameters(1);

            if (lambda<=0)
                error("Lambda has to be strictly greater than zero!")
            end

            % fx = @(x)(lambda*exp(-lambda*x));
            % Fx = @(x)(1-exp(-lambda*x));

            for i=1:n
                U = ULEcuyerRNG;
                X(i) = -(1/lambda)*log(U);
            end

        case 'pelda'

            for i=1:n
                U = ULEcuyerRNG;
                if (U<=0)
                    X(i) = 0;
                elseif (0<U && U<1/2)
                    X(i) = sqrt(U/2);
                elseif(1/2<U && U<=1)
                    X(i)=-(-4+sqrt(-8*U+8))/4;
                 elseif(U>1)
                        X(i)=1;
                 end
                            
                end
    end

    end